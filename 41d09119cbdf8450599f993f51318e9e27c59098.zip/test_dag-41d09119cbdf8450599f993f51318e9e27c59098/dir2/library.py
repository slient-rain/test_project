def add_one(inp):
    return inp + 1
